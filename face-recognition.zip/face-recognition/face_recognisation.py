
#import libraries

from tkinter import * 
import csv
from more_itertools import unique_everseen
import os
import numpy as np
import cv2
from PIL import Image
from datetime import date 
import datetime
from playsound import playsound

#################### Write csv data and append csv data ####################


def create_csv():
        header = ['Student Id', 'Student Name']
        exists = os.path.isfile('data.csv')
        if exists:
                Id = e1.get()
                name = e2.get()
                some_list = [Id , name]
                with open('data.csv', 'a+') as csvFile:
                    writer = csv.writer(csvFile)
                    writer.writerow(some_list)
                csvFile.close()     

        else:        
                header = ['Student Id', 'Student Name']
                Id = e1.get()
                name = e2.get()
                some_list = [Id , name]
                with open('data.csv', 'a+') as csvFile:
                        
                    writer = csv.writer(csvFile)
                    writer.writerow(i for i in header)
                    writer.writerow(some_list)
                    
                csvFile.close()         


#################### facedetection code ####################

def show_data():
   
    faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    
    cap = cv2.VideoCapture(0)
    cap.set(3,640) # set Width
    cap.set(4,480) # set Height
    
    while True:
        ret, img = cap.read()
        img = cv2.flip(img, 1)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(
            gray,
            
            scaleFactor=1.2,
            minNeighbors=5
            ,     
            minSize=(20, 20)
        )
    
        for (x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = img[y:y+h, x:x+w]
            
    
        cv2.imshow('video',img)
    
        k = cv2.waitKey(30) & 0xff
        if k == 27: # press 'ESC' to quit
            break
    
    cap.release()
    cv2.destroyAllWindows()


    ###################### 1_face_dataset #####################
    
    cam = cv2.VideoCapture(0)
    cam.set(3, 640) # set video width
    cam.set(4, 480) # set video height
    face_detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    # For each person, enter one numeric face id
    face_id = input('\n enter user id end press <return> ==>  ')
    print("\n [INFO] Initializing face capture. Look the camera and wait ...")
    # Initialize individual sampling face count
    count = 0
    while(True):
        ret, img = cam.read()
        img = cv2.flip(img, -1) # flip video image vertically
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_detector.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(img, (x,y), (x+w,y+h), (255,0,0), 2)     
            count += 1
            # Save the captured image into the datasets folder
            cv2.imwrite("dataset/User." + str(face_id) + '.' +  
                        str(count) + ".jpg", gray[y:y+h,x:x+w])
            cv2.imshow('image', img)
        k = cv2.waitKey(100) & 0xff # Press 'ESC' for exiting video
        if k == 27:
            break
        elif count >= 30: # Take 30 face sample and stop video
             break
    # Do a bit of cleanup
    print("\n [INFO] Exiting Program and cleanup stuff")
    cam.release()
    cv2.destroyAllWindows()
    
########################## 2_face_training code ##########################

def face_training():
    # Path for face image database
    path = 'dataset'
    
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml");
    
    # function to get the images and label data
    def getImagesAndLabels(path):
    
        imagePaths = [os.path.join(path,f) for f in os.listdir(path)]     
        faceSamples=[]
        ids = []
    
        for imagePath in imagePaths:
    
            PIL_img = Image.open(imagePath).convert('L') # convert it to grayscale
            img_numpy = np.array(PIL_img,'uint8')
    
            id = int(os.path.split(imagePath)[-1].split(".")[1])
            faces = detector.detectMultiScale(img_numpy)
    
            for (x,y,w,h) in faces:
                faceSamples.append(img_numpy[y:y+h,x:x+w])
                ids.append(id)
    
        return faceSamples,ids
    
    print ("\n [INFO] Training faces. It will take a few seconds. Wait ...")
    faces,ids = getImagesAndLabels(path)
    recognizer.train(faces, np.array(ids))
    
    # Save the model into trainer/trainer.yml
    recognizer.write('trainer/trainer.yml') # recognizer.save() worked on Mac, but not on Pi
    
    # Print the numer of faces trained and end program
    print("\n [INFO] {0} faces trained. Exiting Program".format(len(np.unique(ids))))

######################## 3_face_recognisation code ########################

def face_recognisation():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read('trainer/trainer.yml')
    cascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(cascadePath);
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    
    #iniciate id counter
    id = 0
    
    # names related to ids: example ==> Marcelo: id=1,  etc
    names = ['None', 'john', 'marie', 'gia', 'testuser', 'steve', 'Grishma', 'Neel'] 
    
    # Initialize and start realtime video capture
    cam = cv2.VideoCapture(0)
    cam.set(3, 640) # set video widht
    cam.set(4, 480) # set video height
    
    # Define min window size to be recognized as a face
    minW = 0.1*cam.get(3)
    minH = 0.1*cam.get(4)
    
    while True:
    
        ret, img =cam.read()
        img = cv2.flip(img, 1) # Flip vertically
    
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    
        faces = faceCascade.detectMultiScale( 
            gray,
            scaleFactor = 1.2,
            minNeighbors = 5,
            minSize = (int(minW), int(minH)),
           )
    
        for(x,y,w,h) in faces:
    
            cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)
    
            id, confidence = recognizer.predict(gray[y:y+h,x:x+w])
    
            # Check if confidence is less them 100 ==> "0" is perfect match 
            if (confidence < 100):
                id = names[id]
                confidence = "  {0}%".format(round(100 - confidence))
            else:
                id = "unknown"
                confidence = "  {0}%".format(round(100 - confidence))
            
            cv2.putText(img, str(id), (x+5,y-5), font, 1, (255,255,255), 2)
            cv2.putText(img, str(confidence), (x+5,y+h-5), font, 1, (255,255,0), 1)  
        
        cv2.imshow('camera',img) 
    
        k = cv2.waitKey(10) & 0xff # Press 'ESC' for exiting video
        if k == 27:
            break
    
    # Do a bit of cleanup
    print("\n [INFO] Exiting Program and cleanup stuff")
    
    #play thank you sound
    playsound('Thankyou.mp3')
    
    #genereate csv file with recognise data
    header = ['Id', 'Name', 'Current Date', 'Current Time']
    exists = os.path.isfile('recognise.csv')
    if exists:
        Id = "1" #e1.get()
        name = "Test1" #e2.get()
        current_date = date.today()
        currentDT = datetime.datetime.now()
        current_time = currentDT.strftime("%H:%M:%S")
        some_list = [Id , name, current_date, current_time]
        with open('recognise.csv', 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(some_list)
            csvFile.close()     

    else:        
        header = ['Id', 'Name', 'Current Date', 'Current Time']
        Id = "2" #e1.get()
        name = "Test2" #e2.get()
        current_date = date.today()
        currentDT = datetime.datetime.now()
        current_time = currentDT.strftime("%H:%M:%S")
        some_list = [Id , name, current_date, current_time]
        with open('recognise.csv', 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(i for i in header)
            writer.writerow(some_list)
            csvFile.close() 
            
    cam.release()
    cv2.destroyAllWindows()
    
        
        
     


class App:
  def __init__(self, top):
    fm = Frame(top, width=400, height=250, bg="white")
    fm.pack(side=TOP, expand=NO, fill=NONE)
    
    
top = Tk()

#clear text

def clear():
    e1.delete(0,'end')
def clear2():
    e2.delete(0,'end')


top.geometry("400x250")  

display = App(top) 
#creating label  
uid = Label(top, text = "User ID").place(x = 30,y = 50)  
  
#creating label  
uname = Label(top, text = "User name").place(x = 30, y = 90)  

  
b1 = Button(top,text = "Clear",command = clear,activebackground = "gray", activeforeground = "white").place(x = 230, y = 50)

b2 = Button(top,text = "Clear",command = clear2,activebackground = "gray", activeforeground = "white").place(x = 230, y = 90)  


sbmitbtn = Button(top, text = "Submit",command = create_csv,activebackground = "gray", activeforeground = "white").place(x = 100, y = 120)  

show_data_btn = Button(top, text = "Show Data",command = show_data,activebackground = "green", activeforeground = "white").place(x = 100, y = 160)  

face_training_btn = Button(top, text = "Train Data",command = face_training, activebackground = "green", activeforeground = "white").place(x = 180, y = 160)  

face_recognisation_btn = Button(top, text = "Recognise Data",command = face_recognisation, activebackground = "green", activeforeground = "white").place(x = 260, y = 160)  



e1 = Entry(top,width = 20)
e1.place(x = 100, y = 50)

e2 = Entry(top, width = 20)
e2.place(x = 100, y = 90)  



  
top.mainloop()  
